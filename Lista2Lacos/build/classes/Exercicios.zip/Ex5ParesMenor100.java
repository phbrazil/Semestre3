
public class Ex5ParesMenor100 {

    public static void main(String[] args) {

        for (int numero = 100; numero > 0; numero = numero - 2) {
            System.out.println(numero);

        }

    }

}


public class Ex1Inteiros {

    public static void main(String[] args) {

        int numero = 0;

        while (numero < 50) {

            numero = numero + 1;
            System.out.println(numero);

        }

    }

}

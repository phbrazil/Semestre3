
public class Ex4Sequencia10 {

    public static void main(String[] args) {

        for (int sequencia = 10; sequencia <= 1000; sequencia = sequencia + 10) {

            System.out.println(sequencia);

        }

    }
}
